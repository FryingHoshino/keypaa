#include <Keyboard.h>
#include <Mouse.h>
#include <FastLED.h>
#include <EEPROM.h>

// --- KEY PINS ---
// KEY1 and KEY2 are now Hall Effect analog switches (49E sensors)
const int KEY1_PIN = A0; // "u" key, HE sensor
const int KEY2_PIN = A1; // "y" key, HE sensor
const int KEY3_PIN = 6;  // ESC
const int KEY4_PIN = A3; // G
const int KEY5_PIN = 9;  // T

const char KEY1_CHAR = 'y';
const char KEY2_CHAR = 'u';
const char KEY5_CHAR = 't';

// --- HE CALIBRATION + PER-KEY RAPID TRIGGER PROFILES (stored in EEPROM, edited from the PC app) ---
#define SETTINGS_MAGIC 0x4E02
#define NUM_PROFILES 8
struct Profile {
  char    name[8];
  int16_t topDz[2];       // within this of idle = always released
  int16_t botDz[2];       // within this of full = fully pressed
  int16_t rtPress[2];     // rise from lowest point since release = press
  int16_t rtRelease[2];   // drop from highest point since press = release
};
// --- SIGNAL FILTERING (adjustable from the PC app "Filter lab", stored in EEPROM with the rest) ---
// Less filtering = lower latency but more noise: use the app's noise test to see what it costs.
#define FILT_OK 0xA5
struct Filt {
  uint8_t ok;       // FILT_OK once written (older EEPROM layouts leave other bytes here -> defaults)
  uint8_t ovs;      // HE ADC samples averaged per reading, 1..32
  uint8_t adcDiv;   // ADC prescaler bits: 4=/16 5=/32 6=/64 7=/128
  uint8_t dbRel;    // ESC/G/T release debounce, ms (0..50)
  uint8_t reConf;   // encoder switch press confirm, ms (0..100)
};
struct Settings {
  uint16_t magic;
  uint8_t  active;
  uint8_t  reserved;
  int16_t  idle[2];
  int16_t  full[2];
  Profile  prof[NUM_PROFILES];
  Filt     filt;          // appended last so existing EEPROM data (profiles, calibration) stays valid
};
Settings cfg;
#define ACT (cfg.prof[cfg.active])

int key1RtRef = 0;
int key2RtRef = 0;

// --- ROTARY ENCODER (RE) ---
// SW  = up key
// Rotate = Alt + mouse scroll wheel (osu volume control)
const int RE_SW_PIN  = 8;
const int RE_DT_PIN  = 2;  // hardware interrupt pin (INT1)
const int RE_CLK_PIN = 7;  // hardware interrupt pin (INT6)

// --- ADDRESSABLE LED SETUP ---
#define LED_PIN 5      // DIN of LED1, chained to LED2 via DO -> DIN
#define NUM_LEDS 2
CRGB leds[NUM_LEDS];

// Colors shown while each key is held
CRGB KEY1_COLOR = CRGB::Aquamarine;
CRGB KEY2_COLOR = CRGB::Lavender;

// Colors shown after holding past the threshold (e.g. long sliders)
CRGB KEY1_HOLD_COLOR = CRGB::Pink;
CRGB KEY2_HOLD_COLOR = CRGB::White;
const unsigned long LONG_HOLD_TIME = 700; // ms

unsigned long key1PressStart = 0;
unsigned long key2PressStart = 0;
bool key1LongHoldShown = false;
bool key2LongHoldShown = false;
bool reSwPressPending = false;
// rotary
unsigned long reSwPressTimerStart = 0;
const unsigned long PRESS_CONFIRM_TIME = 30; // ms  (default; adjustable: cfg.filt.reConf)

// Fade state (non-blocking transition into hold color)
bool key1Fading = false;
bool key2Fading = false;
unsigned long key1FadeStart = 0;
unsigned long key2FadeStart = 0;
const unsigned long FADE_DURATION = 9000; // ms

// Fade state (non-blocking fade to black on release)
bool key1ReleaseFading = false;
bool key2ReleaseFading = false;
unsigned long key1ReleaseFadeStart = 0;
unsigned long key2ReleaseFadeStart = 0;
CRGB key1ReleaseFadeFrom;
CRGB key2ReleaseFadeFrom;
const unsigned long RELEASE_FADE_DURATION = 200; // ms

// Hardware bounce lockout window (in milliseconds), default; adjustable: cfg.filt.dbRel
// Used for the release of keys 3/4/5 which remain plain digital switches.
const unsigned long DEBOUNCE_TIME = 7;

bool key1Pressed = false;
bool key2Pressed = false;
bool key3Pressed = false;
bool key4Pressed = false;
bool key5Pressed = false;

bool key3ReleasePending = false;
bool key4ReleasePending = false;
bool key5ReleasePending = false;
unsigned long key3ReleaseTimerStart = 0;
unsigned long key4ReleaseTimerStart = 0;
unsigned long key5ReleaseTimerStart = 0;

// --- RE (rotary encoder) state ---
bool reSwPressed = false;

// Full quadrature state-machine decoder (Ben Buxton's algorithm).
#define RE_START      0x0
#define RE_CW_FINAL   0x1
#define RE_CW_BEGIN   0x2
#define RE_CW_NEXT    0x3
#define RE_CCW_BEGIN  0x4
#define RE_CCW_FINAL  0x5
#define RE_CCW_NEXT   0x6
#define RE_DIR_CW     0x10
#define RE_DIR_CCW    0x20

const uint8_t RE_TABLE[7][4] = {
  {RE_START,    RE_CW_BEGIN,  RE_CCW_BEGIN, RE_START},
  {RE_CW_NEXT,  RE_START,     RE_CW_FINAL,  RE_START | RE_DIR_CW},
  {RE_CW_NEXT,  RE_CW_BEGIN,  RE_START,     RE_START},
  {RE_CW_NEXT,  RE_CW_BEGIN,  RE_CW_FINAL,  RE_START},
  {RE_CCW_NEXT, RE_START,     RE_CCW_BEGIN, RE_START},
  {RE_CCW_NEXT, RE_CCW_FINAL, RE_START,     RE_START | RE_DIR_CCW},
  {RE_CCW_NEXT, RE_CCW_FINAL, RE_CCW_BEGIN, RE_START},
};

volatile uint8_t reState = RE_START;
volatile int16_t reDelta = 0; // accumulated detents since last read, +CW / -CCW

void reISR() {
  uint8_t pinState = (digitalRead(RE_CLK_PIN) << 1) | digitalRead(RE_DT_PIN);
  reState = RE_TABLE[reState & 0x0F][pinState];
  uint8_t dir = reState & 0x30;
  if (dir == RE_DIR_CW) {
    reDelta++;
  } else if (dir == RE_DIR_CCW) {
    reDelta--;
  }
}

// Averages cfg.filt.ovs quick ADC reads to smooth out sensor jitter.
// Fewer samples = faster scan + lower latency, but more noise (noise falls ~1/sqrt(samples)).
int smoothRead(int pin) {
  const uint8_t n = cfg.filt.ovs;
  long total = 0;
  for (uint8_t i = 0; i < n; i++) {
    total += analogRead(pin);
  }
  return total / n;
}

// ADC clock = 16 MHz / divider. /32 (500 kHz) cuts each analogRead from ~104 us to ~26 us.
// /16 (1 MHz) is faster still but beyond the ADC's rated clock (less accurate); /128 is the Arduino default.
uint8_t divSel(int d) { return d == 16 ? 4 : d == 32 ? 5 : d == 64 ? 6 : d == 128 ? 7 : 0; }
void applyAdc() { ADCSRA = (ADCSRA & ~0x07) | (cfg.filt.adcDiv & 0x07); }

void setFiltDefaults() {
  cfg.filt.ok = FILT_OK;
  cfg.filt.ovs = 8;
  cfg.filt.adcDiv = 5;
  cfg.filt.dbRel = DEBOUNCE_TIME;
  cfg.filt.reConf = PRESS_CONFIRM_TIME;
}

void sanitizeFilt() {
  cfg.filt.ovs = constrain(cfg.filt.ovs, 1, 32);
  if (cfg.filt.adcDiv < 4 || cfg.filt.adcDiv > 7) cfg.filt.adcDiv = 5;
  if (cfg.filt.dbRel > 50) cfg.filt.dbRel = 50;
  if (cfg.filt.reConf > 100) cfg.filt.reConf = 100;
}

// Rapid Trigger with top/bottom deadzones.
// Returns true if the key should be pressed. `ref` holds the peak while pressed
// and the valley while released (must persist between calls, one per key).
bool rapidTrigger(int val, int idle, int maxVal, bool pressed, int &ref, int topDz, int botDz, int rtPress, int rtRelease) {
  const int topEdge    = idle + topDz;
  const int bottomEdge = maxVal - botDz;

  // Top deadzone: always released, valley resets to the edge of the deadzone
  if (val <= topEdge) {
    ref = topEdge;
    return false;
  }

  // Bottom deadzone: anything past bottomEdge counts as bottomEdge
  int v = (val > bottomEdge) ? bottomEdge : val;

  if (pressed) {
    if (v > ref) ref = v;                       // follow the peak
    if (v <= ref - rtRelease) {           // dropped enough from the peak
      ref = v;                                  // start tracking the valley here
      return false;
    }
    return true;
  }

  if (v < ref) ref = v;                         // follow the valley
  if (v >= ref + rtPress) {               // risen enough from the valley
    ref = v;                                    // start tracking the peak here
    return true;
  }
  return false;
}

// ===================== PC TUNING APP PROTOCOL =====================
// GET | STREAM n | KEYS n | CALR | CALP k | RT k p r | DZ k t b   (RT/DZ edit the ACTIVE profile)
// PROF n | PNAME n txt | PCOPY a b | PRESET n | SAVE | DEFAULTS
// FILT ovs div dbRel reConf -> set filtering (div = 16/32/64/128), replies F,ovs,div,dbRel,reConf
// NOISE ms -> blocking sensor noise test (keys at rest), replies N,n,ref0,sumD0,sumD2_0,min0,max0,ref1,...
// While STREAM is on, T,avgLoopUs,maxLoopUs,avgReadUs is sent every 500 ms (scan timing)
// EVT n   -> key edge events  E<lane><down><micros>      (latency logging)
// SCOPE n -> fast sensor samples  W<micros><v0><v1><ref0><ref1><flags>  (hex, fixed width)
// SYNC id -> S<id><micros>   (PC<->device clock sync)
// Streams are queued in tiny ring buffers and only written when the USB buffer has room,
// so they can never block the key loop.
bool kbEnabled = true, streaming = false, evtOn = false, scopeOn = false;
unsigned long lastStream = 0;
int lastVal[2] = {0, 0};
char cmdBuf[40];
uint8_t cmdLen = 0;

// scan-loop timing, reported as "T," lines so the app can show what the filter costs
uint32_t stN = 0, stLoopSum = 0, stLoopMax = 0, stReadSum = 0, lastLoopT = 0;
unsigned long lastStat = 0;
inline void statLoop(uint32_t now) {
  if (lastLoopT) {
    uint32_t d = now - lastLoopT;
    stLoopSum += d;
    if (d > stLoopMax) stLoopMax = d;
    stN++;
  }
  lastLoopT = now;
}
void statReset() { stN = stLoopSum = stLoopMax = stReadSum = 0; lastLoopT = 0; }   // also after blocking work (calibration, noise test)

struct Ev  { uint32_t t; uint8_t code; };
struct Smp { uint32_t t; uint16_t v0, v1, r0, r1; uint8_t f; };
#define EVQ 32
#define SMQ 16
Ev  evq[EVQ];  uint8_t evHead = 0, evTail = 0;
Smp smq[SMQ];  uint8_t smHead = 0, smTail = 0;

inline void kbPress(uint8_t k)   { if (kbEnabled) Keyboard.press(k); }
inline void kbRelease(uint8_t k) { if (kbEnabled) Keyboard.release(k); }

inline void logEv(uint8_t lane, bool down) {
  if (!evtOn) return;
  uint8_t n = (evHead + 1) & (EVQ - 1);
  if (n == evTail) return;
  evq[evHead].t = micros();
  evq[evHead].code = (lane << 1) | (down ? 1 : 0);
  evHead = n;
}

inline void pushSample(int v0, int v1, int r0, int r1, bool p0, bool p1) {
  if (!scopeOn) return;
  uint8_t n = (smHead + 1) & (SMQ - 1);
  if (n == smTail) return;
  Smp& s = smq[smHead];
  s.t = micros();
  s.v0 = v0 & 0x3FF; s.v1 = v1 & 0x3FF; s.r0 = r0 & 0x3FF; s.r1 = r1 & 0x3FF;
  s.f = (p0 ? 1 : 0) | (p1 ? 2 : 0);
  smHead = n;
}

static const char HEXD[] = "0123456789ABCDEF";
inline char* hexw(char* p, uint32_t v, uint8_t digits) {
  for (int8_t i = digits - 1; i >= 0; i--) { p[i] = HEXD[v & 0xF]; v >>= 4; }
  return p + digits;
}

void flushStreams() {
  char b[24];
  while (evTail != evHead && Serial.availableForWrite() >= 12) {
    char* p = b;
    *p++ = 'E';
    p = hexw(p, evq[evTail].code >> 1, 1);
    p = hexw(p, evq[evTail].code & 1, 1);
    p = hexw(p, evq[evTail].t, 8);
    *p++ = '\n';
    Serial.write((uint8_t*)b, p - b);
    evTail = (evTail + 1) & (EVQ - 1);
  }
  while (smTail != smHead && Serial.availableForWrite() >= 24) {
    const Smp& s = smq[smTail];
    char* p = b;
    *p++ = 'W';
    p = hexw(p, s.t, 8);
    p = hexw(p, s.v0, 3); p = hexw(p, s.v1, 3); p = hexw(p, s.r0, 3); p = hexw(p, s.r1, 3);
    p = hexw(p, s.f, 1);
    *p++ = '\n';
    Serial.write((uint8_t*)b, p - b);
    smTail = (smTail + 1) & (SMQ - 1);
  }
}

void resetProfile(uint8_t n) {
  Profile& p = cfg.prof[n];
  memset(&p, 0, sizeof(p));
  if (n == 0) strcpy(p.name, "osu"); else { p.name[0] = 'P'; p.name[1] = '1' + n; }
  for (uint8_t k = 0; k < 2; k++) { p.topDz[k] = 14; p.botDz[k] = 10; p.rtPress[k] = 10; p.rtRelease[k] = 10; }
}

void loadDefaults() {
  cfg.magic = SETTINGS_MAGIC; cfg.active = 0; cfg.reserved = 0;
  cfg.idle[0] = 620; cfg.full[0] = 923;       // your original hand-tuned values
  cfg.idle[1] = 616; cfg.full[1] = 926;
  for (uint8_t n = 0; n < NUM_PROFILES; n++) resetProfile(n);
  setFiltDefaults();
}

struct OldSettings { uint16_t magic; int16_t idle[2], full[2]; int16_t topDz, botDz, rtPress, rtRelease; };

void loadSettings() {
  EEPROM.get(0, cfg);
  if (cfg.magic == SETTINGS_MAGIC) {
    if (cfg.filt.ok != FILT_OK) setFiltDefaults(); else sanitizeFilt();   // EEPROM from before the filter settings existed
    return;
  }
  OldSettings o;
  EEPROM.get(0, o);                            // migrate the previous (single-profile) layout
  loadDefaults();
  if (o.magic == 0x4E01) {
    for (uint8_t k = 0; k < 2; k++) { cfg.idle[k] = o.idle[k]; cfg.full[k] = o.full[k]; }
    for (uint8_t n = 0; n < NUM_PROFILES; n++)
      for (uint8_t k = 0; k < 2; k++) {
        cfg.prof[n].topDz[k] = o.topDz; cfg.prof[n].botDz[k] = o.botDz;
        cfg.prof[n].rtPress[k] = o.rtPress; cfg.prof[n].rtRelease[k] = o.rtRelease;
      }
  }
}

void resetRtRefs() {
  key1RtRef = cfg.idle[0] + ACT.topDz[0];
  key2RtRef = cfg.idle[1] + ACT.topDz[1];
}

void sendCfg() {
  char b[48];
  snprintf(b, sizeof(b), "C,%d,%d,%d,%d", cfg.idle[0], cfg.full[0], cfg.idle[1], cfg.full[1]);
  Serial.println(b);
}

void sendFilt() {
  char b[40];
  snprintf(b, sizeof(b), "F,%d,%d,%d,%d", cfg.filt.ovs, 1 << cfg.filt.adcDiv, cfg.filt.dbRel, cfg.filt.reConf);
  Serial.println(b);
}

void sendProfile(uint8_t n) {
  const Profile& p = cfg.prof[n];
  char b[72];
  snprintf(b, sizeof(b), "P,%d,%s,%d,%d,%d,%d,%d,%d,%d,%d", n, p.name,
           p.topDz[0], p.botDz[0], p.rtPress[0], p.rtRelease[0],
           p.topDz[1], p.botDz[1], p.rtPress[1], p.rtRelease[1]);
  Serial.println(b);
}

void sendAll() {
  sendCfg();
  for (uint8_t n = 0; n < NUM_PROFILES; n++) sendProfile(n);
  Serial.print("A,");
  Serial.println((int)cfg.active);
}

// Average of many smoothRead() results over `ms` milliseconds (calibration only).
int calAvg(int pin, unsigned long ms) {
  unsigned long end = millis() + ms;
  long sum = 0;
  int n = 0;
  while (millis() < end) { sum += smoothRead(pin); n++; }
  return n ? (int)(sum / n) : 0;
}

// Samples both HE keys with the CURRENT filter settings while they rest and reports raw sums, so the
// app can compute mean / standard deviation / peak-to-peak without any float maths here. Blocking, like calibration.
void noiseTest(unsigned long ms) {
  const int pins[2] = { KEY1_PIN, KEY2_PIN };
  int16_t ref[2] = { 0, 0 }, mn[2] = { 0, 0 }, mx[2] = { 0, 0 };
  int32_t sumD[2] = { 0, 0 };
  uint32_t sumD2[2] = { 0, 0 };
  uint32_t n = 0;
  unsigned long end = millis() + ms;
  while ((long)(end - millis()) > 0 && n < 60000UL) {
    for (uint8_t k = 0; k < 2; k++) {
      int v = smoothRead(pins[k]);
      if (n == 0) { ref[k] = v; mn[k] = v; mx[k] = v; }
      if (v < mn[k]) mn[k] = v;
      if (v > mx[k]) mx[k] = v;
      int32_t d = constrain(v - ref[k], -255, 255);   // deviation from the first reading keeps the sums small
      sumD[k] += d;
      sumD2[k] += (uint32_t)(d * d);
    }
    n++;
  }
  char b[96];
  snprintf(b, sizeof(b), "N,%lu,%d,%ld,%lu,%d,%d,%d,%ld,%lu,%d,%d", (unsigned long)n,
           ref[0], (long)sumD[0], (unsigned long)sumD2[0], mn[0], mx[0],
           ref[1], (long)sumD[1], (unsigned long)sumD2[1], mn[1], mx[1]);
  Serial.println(b);
  resetRtRefs();
  statReset();
}

void handleCmd(char* s) {
  int a, b, c, d;
  char nm[9];
  if (!strcmp(s, "GET")) {
    sendAll();
    sendFilt();
  } else if (sscanf(s, "STREAM %d", &a) == 1) {
    streaming = (a != 0);
    Serial.println("OK STREAM");
  } else if (sscanf(s, "KEYS %d", &a) == 1) {
    bool en = (a != 0);
    if (en != kbEnabled) {
      if (!en) {
        Keyboard.release(KEY1_CHAR);
        Keyboard.release(KEY2_CHAR);
        kbEnabled = false;
      } else {
        kbEnabled = true;
        if (key1Pressed) Keyboard.press(KEY1_CHAR);
        if (key2Pressed) Keyboard.press(KEY2_CHAR);
      }
    }
    Serial.println("OK KEYS");
  } else if (sscanf(s, "EVT %d", &a) == 1) {
    evtOn = (a != 0); evHead = evTail = 0;
    Serial.println("OK EVT");
  } else if (sscanf(s, "SCOPE %d", &a) == 1) {
    scopeOn = (a != 0); smHead = smTail = 0;
    Serial.println("OK SCOPE");
  } else if (sscanf(s, "SYNC %d", &a) == 1) {
    uint32_t t = micros();
    if (Serial.availableForWrite() >= 14) {
      char sb[14];
      char* p = sb;
      *p++ = 'S';
      p = hexw(p, (uint32_t)a, 4);
      p = hexw(p, t, 8);
      *p++ = '\n';
      Serial.write((uint8_t*)sb, p - sb);
    }
  } else if (!strcmp(s, "CALR")) {
    cfg.idle[0] = calAvg(KEY1_PIN, 300);
    cfg.idle[1] = calAvg(KEY2_PIN, 300);
    resetRtRefs();
    statReset();
    sendCfg();
    Serial.println("OK CALR");
  } else if (sscanf(s, "CALP %d", &a) == 1 && (a == 0 || a == 1)) {
    cfg.full[a] = calAvg(a == 0 ? KEY1_PIN : KEY2_PIN, 400);
    statReset();
    sendCfg();
    Serial.println("OK CALP");
  } else if (sscanf(s, "FILT %d %d %d %d", &a, &b, &c, &d) == 4 && divSel(b)) {
    cfg.filt.ok     = FILT_OK;
    cfg.filt.ovs    = constrain(a, 1, 32);
    cfg.filt.adcDiv = divSel(b);
    cfg.filt.dbRel  = constrain(c, 0, 50);
    cfg.filt.reConf = constrain(d, 0, 100);
    applyAdc();
    statReset();            // timing numbers must describe the new setting only
    sendFilt();
    Serial.println("OK FILT");
  } else if (sscanf(s, "NOISE %d", &a) == 1) {
    noiseTest(constrain(a, 100, 5000));
  } else if (sscanf(s, "RT %d %d %d", &a, &b, &c) == 3 && (a == 0 || a == 1)) {
    ACT.rtPress[a]   = constrain(b, 1, 100);
    ACT.rtRelease[a] = constrain(c, 1, 100);
    Serial.println("OK RT");
  } else if (sscanf(s, "DZ %d %d %d", &a, &b, &c) == 3 && (a == 0 || a == 1)) {
    ACT.topDz[a] = constrain(b, 0, 100);
    ACT.botDz[a] = constrain(c, 0, 100);
    resetRtRefs();
    Serial.println("OK DZ");
  } else if (sscanf(s, "PROF %d", &a) == 1 && a >= 0 && a < NUM_PROFILES) {
    cfg.active = a;
    resetRtRefs();
    sendAll();
  } else if (sscanf(s, "PNAME %d %8s", &a, nm) == 2 && a >= 0 && a < NUM_PROFILES) {
    memset(cfg.prof[a].name, 0, 8);
    for (uint8_t i = 0; i < 7 && nm[i]; i++) cfg.prof[a].name[i] = (nm[i] <= 32 || nm[i] == ',') ? '_' : nm[i];
    Serial.println("OK PNAME");
  } else if (sscanf(s, "PCOPY %d %d", &a, &b) == 2 && a >= 0 && a < NUM_PROFILES && b >= 0 && b < NUM_PROFILES) {
    cfg.prof[b] = cfg.prof[a];
    resetRtRefs();
    sendAll();
  } else if (sscanf(s, "PRESET %d", &a) == 1 && a >= 0 && a < NUM_PROFILES) {
    resetProfile(a);
    resetRtRefs();
    sendAll();
  } else if (!strcmp(s, "SAVE")) {
    EEPROM.put(0, cfg);   // put() only rewrites bytes that actually changed
    Serial.println("OK SAVE");
  } else if (!strcmp(s, "DEFAULTS")) {
    loadDefaults();
    applyAdc();
    statReset();
    resetRtRefs();
    sendAll();
    sendFilt();
  } else {
    Serial.println("ERR");
  }
}

void serialTask(unsigned long now) {
  while (Serial.available()) {
    char c = Serial.read();
    if (c == '\r') continue;
    if (c == '\n') {
      cmdBuf[cmdLen] = 0;
      if (cmdLen) handleCmd(cmdBuf);
      cmdLen = 0;
    } else if (cmdLen < sizeof(cmdBuf) - 1) {
      cmdBuf[cmdLen++] = c;
    }
  }

  flushStreams();

  if (streaming && (now - lastStream) >= 20 && Serial.availableForWrite() >= 24) {
    lastStream = now;
    char b[24];
    int n = snprintf(b, sizeof(b), "V,%d,%d,%d,%d\n", lastVal[0], lastVal[1], key1Pressed ? 1 : 0, key2Pressed ? 1 : 0);
    Serial.write((uint8_t*)b, n);
  }

  if (streaming && stN > 0 && (now - lastStat) >= 500 && Serial.availableForWrite() >= 36) {
    lastStat = now;
    char b[36];
    int n = snprintf(b, sizeof(b), "T,%lu,%lu,%lu\n", (unsigned long)(stLoopSum / stN), (unsigned long)stLoopMax, (unsigned long)(stReadSum / stN));
    Serial.write((uint8_t*)b, n);
    statReset();
  }
}

void setup() {
  // KEY1_PIN / KEY2_PIN are analog HE sensors - no pinMode/pullup needed,
  // analogRead() works on them directly.
  pinMode(KEY3_PIN, INPUT_PULLUP);
  pinMode(KEY4_PIN, INPUT_PULLUP);
  pinMode(KEY5_PIN, INPUT_PULLUP);

  pinMode(RE_SW_PIN, INPUT_PULLUP);
  pinMode(RE_DT_PIN, INPUT_PULLUP);
  pinMode(RE_CLK_PIN, INPUT_PULLUP);
  attachInterrupt(digitalPinToInterrupt(RE_DT_PIN), reISR, CHANGE);
  attachInterrupt(digitalPinToInterrupt(RE_CLK_PIN), reISR, CHANGE);

  FastLED.addLeds<WS2812B, LED_PIN, GRB>(leds, NUM_LEDS);
  FastLED.setBrightness(64);
  leds[0] = CRGB::Black;
  leds[1] = CRGB::Black;
  FastLED.show();

  loadSettings();
  applyAdc();   // ADC clock comes from the saved filter settings (default /32)
  resetRtRefs();
  Serial.begin(115200);

  Keyboard.begin();
  Mouse.begin();
}

void loop() {
  unsigned long currentTime = millis();
  statLoop(micros());
  bool ledNeedsUpdate = false;

  // --- KEY 1 (HE, rapid trigger - no debounce needed, analog signal is clean) ---
  uint32_t rt0 = micros();
  int val1 = smoothRead(KEY1_PIN);
  stReadSum += micros() - rt0;
  lastVal[0] = val1;
  bool pinState1 = rapidTrigger(val1, cfg.idle[0], cfg.full[0], key1Pressed, key1RtRef, ACT.topDz[0], ACT.botDz[0], ACT.rtPress[0], ACT.rtRelease[0]);

  if (pinState1 && !key1Pressed) {
    key1Pressed = true;
    logEv(0, true);
    kbPress(KEY1_CHAR);
    leds[0] = KEY1_COLOR;
    key1PressStart = currentTime;
    key1LongHoldShown = false;
    key1Fading = false;
    key1ReleaseFading = false;
    ledNeedsUpdate = true;
  } else if (!pinState1 && key1Pressed) {
    key1Pressed = false;
    logEv(0, false);
    kbRelease(KEY1_CHAR);
    key1ReleaseFadeFrom = leds[0];
    key1ReleaseFading = true;
    key1ReleaseFadeStart = currentTime;
    key1Fading = false;
    ledNeedsUpdate = true;
  }

  // While Key 1 is held, check if it has crossed the long-hold threshold
  if (key1Pressed && !key1LongHoldShown) {
    if ((currentTime - key1PressStart) >= LONG_HOLD_TIME) {
      key1LongHoldShown = true;
      key1Fading = true;
      key1FadeStart = currentTime;
    }
  }

  // Advance Key 1's fade a little each loop pass (non-blocking)
  if (key1Fading) {
    unsigned long elapsed = currentTime - key1FadeStart;
    if (elapsed >= FADE_DURATION) {
      leds[0] = KEY1_HOLD_COLOR;
      key1Fading = false;
    } else {
      uint8_t progress = map(elapsed, 0, FADE_DURATION, 0, 255);
      leds[0] = blend(KEY1_COLOR, KEY1_HOLD_COLOR, progress);
    }
    ledNeedsUpdate = true;
  }

  // Advance Key 1's fade-to-black on release (non-blocking)
  if (key1ReleaseFading) {
    unsigned long elapsed = currentTime - key1ReleaseFadeStart;
    if (elapsed >= RELEASE_FADE_DURATION) {
      leds[0] = CRGB::Black;
      key1ReleaseFading = false;
    } else {
      uint8_t progress = map(elapsed, 0, RELEASE_FADE_DURATION, 0, 255);
      leds[0] = blend(key1ReleaseFadeFrom, CRGB::Black, progress);
    }
    ledNeedsUpdate = true;
  }

  // --- KEY 2 (HE, rapid trigger) ---
  rt0 = micros();
  int val2 = smoothRead(KEY2_PIN);
  stReadSum += micros() - rt0;
  lastVal[1] = val2;
  bool pinState2 = rapidTrigger(val2, cfg.idle[1], cfg.full[1], key2Pressed, key2RtRef, ACT.topDz[1], ACT.botDz[1], ACT.rtPress[1], ACT.rtRelease[1]);

  if (pinState2 && !key2Pressed) {
    key2Pressed = true;
    logEv(1, true);
    kbPress(KEY2_CHAR);
    leds[1] = KEY2_COLOR;
    key2PressStart = currentTime;
    key2LongHoldShown = false;
    key2Fading = false;
    key2ReleaseFading = false;
    ledNeedsUpdate = true;
  } else if (!pinState2 && key2Pressed) {
    key2Pressed = false;
    logEv(1, false);
    kbRelease(KEY2_CHAR);
    key2ReleaseFadeFrom = leds[1];
    key2ReleaseFading = true;
    key2ReleaseFadeStart = currentTime;
    key2Fading = false;
    ledNeedsUpdate = true;
  }

  // While Key 2 is held, check if it has crossed the long-hold threshold
  if (key2Pressed && !key2LongHoldShown) {
    if ((currentTime - key2PressStart) >= LONG_HOLD_TIME) {
      key2LongHoldShown = true;
      key2Fading = true;
      key2FadeStart = currentTime;
    }
  }

  // Advance Key 2's fade a little each loop pass (non-blocking)
  if (key2Fading) {
    unsigned long elapsed = currentTime - key2FadeStart;
    if (elapsed >= FADE_DURATION) {
      leds[1] = KEY2_HOLD_COLOR;
      key2Fading = false;
    } else {
      uint8_t progress = map(elapsed, 0, FADE_DURATION, 0, 255);
      leds[1] = blend(KEY2_COLOR, KEY2_HOLD_COLOR, progress);
    }
    ledNeedsUpdate = true;
  }

  // Advance Key 2's fade-to-black on release (non-blocking)
  if (key2ReleaseFading) {
    unsigned long elapsed = currentTime - key2ReleaseFadeStart;
    if (elapsed >= RELEASE_FADE_DURATION) {
      leds[1] = CRGB::Black;
      key2ReleaseFading = false;
    } else {
      uint8_t progress = map(elapsed, 0, RELEASE_FADE_DURATION, 0, 255);
      leds[1] = blend(key2ReleaseFadeFrom, CRGB::Black, progress);
    }
    ledNeedsUpdate = true;
  }

  pushSample(val1, val2, key1RtRef, key2RtRef, key1Pressed, key2Pressed);

  // --- KEY 3 (ESC) - unchanged, plain digital switch ---
  bool pinState3 = (digitalRead(KEY3_PIN) == LOW);

  if (pinState3 && !key3Pressed) {
    key3Pressed = true;
    key3ReleasePending = false;
    logEv(2, true);
    Keyboard.press(KEY_ESC);
  } else if (!pinState3 && key3Pressed) {
    if (!key3ReleasePending) {
      key3ReleasePending = true;
      key3ReleaseTimerStart = currentTime;
    }
    if ((currentTime - key3ReleaseTimerStart) >= cfg.filt.dbRel) {
      key3Pressed = false;
      key3ReleasePending = false;
      logEv(2, false);
      Keyboard.release(KEY_ESC);
    }
  } else if (pinState3 && key3Pressed && key3ReleasePending) {
    key3ReleasePending = false;
  }

  // --- KEY 4 (G) - unchanged, plain digital switch ---
  bool pinState4 = (digitalRead(KEY4_PIN) == LOW);

  if (pinState4 && !key4Pressed) {
    key4Pressed = true;
    key4ReleasePending = false;
    logEv(3, true);
    Keyboard.press('g');
  } else if (!pinState4 && key4Pressed) {
    if (!key4ReleasePending) {
      key4ReleasePending = true;
      key4ReleaseTimerStart = currentTime;
    }
    if ((currentTime - key4ReleaseTimerStart) >= cfg.filt.dbRel) {
      key4Pressed = false;
      key4ReleasePending = false;
      logEv(3, false);
    Keyboard.release('g');
    }
  } else if (pinState4 && key4Pressed && key4ReleasePending) {
    key4ReleasePending = false;
  }

  // --- KEY 5 (T) - unchanged, plain digital switch ---
  bool pinState5 = (digitalRead(KEY5_PIN) == LOW);

  if (pinState5 && !key5Pressed) {
    key5Pressed = true;
    key5ReleasePending = false;
    logEv(4, true);
    Keyboard.press(KEY5_CHAR);
  } else if (!pinState5 && key5Pressed) {
    if (!key5ReleasePending) {
      key5ReleasePending = true;
      key5ReleaseTimerStart = currentTime;
    }
    if ((currentTime - key5ReleaseTimerStart) >= cfg.filt.dbRel) {
      key5Pressed = false;
      key5ReleasePending = false;
      logEv(4, false);
    Keyboard.release(KEY5_CHAR);
    }
  } else if (pinState5 && key5Pressed && key5ReleasePending) {
    key5ReleasePending = false;
  }

  // --- RE SWITCH (Up arrow) - unchanged ---
  bool reSwState = (digitalRead(RE_SW_PIN) == LOW);

  if (reSwState && !reSwPressed) {
    if (!reSwPressPending) {
      reSwPressPending = true;
      reSwPressTimerStart = currentTime;
    }
    if ((currentTime - reSwPressTimerStart) >= cfg.filt.reConf) {
      reSwPressed = true;
      reSwPressPending = false;
      logEv(5, true);
    Keyboard.press(KEY_LEFT_ARROW);
    }
  } else if (!reSwState && reSwPressed) {
    reSwPressed = false;
    logEv(5, false);
    Keyboard.release(KEY_LEFT_ARROW);
  } else if (!reSwState && reSwPressPending) {
    reSwPressPending = false;
  }

  // --- RE ROTATION (Alt + mouse scroll, e.g. osu! volume control) - unchanged ---
  noInterrupts();
  int16_t reSteps = reDelta;
  reDelta = 0;
  interrupts();

  if (reSteps != 0) {
    logEv(6, true);
    Keyboard.press(KEY_LEFT_ALT);
    Mouse.move(0, 0, reSteps); // positive = CW, negative = CCW
    Keyboard.release(KEY_LEFT_ALT);
    logEv(6, false);
  }

  if (ledNeedsUpdate) {
    FastLED.show();
  }

  serialTask(currentTime);
}
